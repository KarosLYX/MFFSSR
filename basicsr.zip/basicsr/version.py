# GENERATED VERSION FILE
# TIME: Thu Jan 18 11:33:57 2024
__version__ = '1.2.0+50cb149'
short_version = '1.2.0'
version_info = (1, 2, 0)
